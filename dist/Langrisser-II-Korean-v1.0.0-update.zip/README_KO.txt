랑그릿사 II 한국어판 ROM 업데이트 (ko-1.0.0)

중요
1. 에뮬레이터를 완전히 종료합니다.
2. 게임 안에서 저장한 뒤 업데이트합니다.
3. 상태 저장(save state)은 ROM 코드 주소를 포함할 수 있어 호환을 보장하지 않습니다.
4. 이 패치는 SRAM, .srm, .sav, .state 파일을 열거나 수정하지 않습니다.

Windows
- ROM 파일을 apply_update.bat 위로 끌어 놓거나 apply_update.bat를 실행합니다.
- Python 3가 필요합니다.
- 업데이트 전 ROM은 같은 폴더에 .bak로 백업됩니다.
- ROM 경로와 파일명은 그대로 유지되므로 기존 SRAM 저장명이 바뀌지 않습니다.

Linux/macOS
- ./apply_update.sh "/path/to/Langrisser II (Korean).md"

Android/RetroArch
- patches 폴더에서 자신의 이전 버전에 맞는 .bps 파일을 BPS 패처로 적용합니다.
- 패치 결과 ROM을 기존 ROM과 정확히 같은 파일명으로 둡니다.
- 기존 ROM은 먼저 다른 폴더에 백업합니다.
- RetroArch의 저장 디렉터리에 있는 기존 .srm 파일은 그대로 둡니다.

검증만 하기
python3 apply_update.py apply --package . --rom "ROM경로" --dry-run

지원하지 않는 ROM, 이미 수정된 ROM, 손상된 패치는 쓰기 전에 거부됩니다.
