@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
set "ROM=%~1"
if not defined ROM set /p "ROM=업데이트할 한국어판 ROM 경로: "
where py >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  py -3 apply_update.py apply --package . --rom "%ROM%"
) else (
  python apply_update.py apply --package . --rom "%ROM%"
)
set "RESULT=%ERRORLEVEL%"
pause
exit /b %RESULT%
