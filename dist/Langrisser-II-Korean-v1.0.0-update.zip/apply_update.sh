#!/bin/sh
set -eu
cd "$(dirname "$0")"
rom=${1-}
if [ -z "$rom" ]; then
  printf '업데이트할 한국어판 ROM 경로: '
  IFS= read -r rom
fi
python3 apply_update.py apply --package . --rom "$rom"
